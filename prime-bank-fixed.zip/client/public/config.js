// عدّل هذا الملف فقط: ضع Application ID من Discord Developer Portal
window.__CFG = { CLIENT_ID: "ضع_Application_ID_هنا" };
