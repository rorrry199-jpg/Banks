import { DiscordSDK } from "@discord/embedded-app-sdk";
import "./style.css";
import COMMANDS from "./commands.json";
import { admin } from "./admin.js";

const CID = (window.__CFG && window.__CFG.CLIENT_ID) || import.meta.env.VITE_DISCORD_CLIENT_ID;
const sdk = new DiscordSDK(CID);
const root = document.getElementById("app");
const fmt = (n) => Math.round(n || 0).toLocaleString("en-US");
// عناصر بـ textContent فقط (لا innerHTML) = حماية من XSS
const el = (tag, props = {}, ...kids) => { const n = Object.assign(document.createElement(tag), props); for (const k of kids.flat()) if (k != null) n.append(k); return n; };
const btn = (text, onclick, cls = "") => el("button", { className: "btn " + cls, textContent: text, onclick });

let session = null, user = null, me = null, tab = "home", game = "mines", toastTimer;
const G = { mines: null, hilo: null }, last = {};

async function login() {
  await sdk.ready();
  const { code } = await sdk.commands.authorize({ client_id: CID, response_type: "code", state: "", prompt: "none", scope: ["identify", "guilds"] });
  const r = await fetch("/.proxy/api/token", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code }) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || "فشل تسجيل الدخول");
  session = d.session; user = d.user; user.owner = d.owner;
  await sdk.commands.authenticate({ access_token: d.access_token });
}
async function api(path, body) {
  const call = () => fetch("/.proxy/api/" + path, { method: body ? "POST" : "GET", headers: { "Content-Type": "application/json", Authorization: "Bearer " + session }, body: body ? JSON.stringify(body) : undefined });
  let r = await call();
  if (r.status === 401) { await login(); r = await call(); }
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || "خطأ");
  return d;
}
function toast(text, ok = true) {
  document.querySelector(".toast")?.remove(); clearTimeout(toastTimer);
  document.body.append(el("div", { className: "toast " + (ok ? "ok" : "err"), textContent: text }));
  toastTimer = setTimeout(() => document.querySelector(".toast")?.remove(), 3200);
}
const play = async (body) => {
  try {
    const d = await api("game", body);
    me.balance = d.balance;
    if (body.game !== "dice") G[body.game] = d.game;
    last[body.game] = d;
    if (d.over) toast(d.over.win ? `🎉 ربحت ${fmt(d.over.payout)}` : "💥 خسرت الجولة", d.over.win);
    if (d.dice) toast(d.dice.tie ? "تعادل — رجع رهانك" : d.dice.win ? `🎉 ربحت ${fmt(d.dice.payout)}` : "خسرت الجولة", d.dice.win || d.dice.tie);
    draw();
  } catch (e) { toast("❌ " + e.message, false); }
};

// ---------- مكونات ----------
function betBox() {
  const input = el("input", { type: "text", inputMode: "numeric", placeholder: "المبلغ", value: last.bet || "1k", maxLength: 12 });
  input.oninput = () => (last.bet = input.value);
  const chip = (t, v) => el("button", { className: "chip", textContent: t, onclick: () => { input.value = v; last.bet = v; } });
  return { input, node: el("div", { className: "bet" }, input, el("div", { className: "chips" }, chip("1K", "1k"), chip("10K", "10k"), chip("100K", "100k"), chip("½", "half"), chip("كل", "all"))) };
}
const stat = (k, v, cls = "") => el("div", { className: "stat " + cls }, el("span", { textContent: k }), el("b", { textContent: v }));

// ---------- الألعاب ----------
function minesView() {
  const g = G.mines, bet = betBox();
  if (!g) {
    const bombs = el("select", {}, ...[1, 2, 3, 5, 7, 10].map((n) => el("option", { value: n, textContent: n + " قنابل", selected: n === 3 })));
    const done = last.mines?.over;
    return el("div", { className: "panel" },
      el("p", { className: "hint", textContent: "افتح المربعات، كل ماسة تزيد المضاعف. اسحب ربحك قبل ما تطلع قنبلة." }),
      bet.node, bombs, btn("ابدأ اللعبة", () => play({ game: "mines", action: "start", bet: bet.input.value, bombs: bombs.value }), "primary"),
      done ? el("div", { className: "res " + (done.win ? "win" : "lose"), textContent: done.win ? `ربحت ${fmt(done.payout)}` : "خسرت الرهان" }) : null);
  }
  const over = last.mines?.over && !G.mines;
  const cells = [...Array(16).keys()].map((i) => el("button", { className: "cell" + (g.open.includes(i) ? " gem" : ""), textContent: g.open.includes(i) ? "💎" : "", onclick: () => play({ game: "mines", action: "open", i }) }));
  return el("div", { className: "panel" },
    el("div", { className: "stats" }, stat("الرهان", fmt(g.bet)), stat("المضاعف", "x" + g.mult), stat("الربح الحالي", fmt(g.payout), "gold"), stat("التالي", "x" + g.next)),
    el("div", { className: "grid" }, cells),
    btn(`سحب ${fmt(g.payout)}`, () => play({ game: "mines", action: "cash" }), "success"));
}
const CARD = ["", "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
function hiloView() {
  const g = G.hilo, bet = betBox(), r = last.hilo;
  if (!g) {
    return el("div", { className: "panel" },
      el("p", { className: "hint", textContent: "خمّن الكرت الجاي: أعلى أو أقل أو مساوي. كل تخمين صح يضرب المضاعف (حتى x100)." }),
      bet.node, btn("ابدأ اللعبة", () => play({ game: "hilo", action: "start", bet: bet.input.value }), "primary"),
      r?.over ? el("div", { className: "res " + (r.over.win ? "win" : "lose") }, `الكرت الأخير: ${CARD[r.over.next] || ""} — ${r.over.win ? "ربحت " + fmt(r.over.payout) : "خسرت الرهان"}`) : null);
  }
  const o = g.opts, b = (t, k) => el("button", { className: "btn guess", disabled: !o[k], onclick: () => play({ game: "hilo", action: "guess", g: k }) }, el("span", { textContent: t }), el("small", { textContent: o[k] ? "x" + o[k] : "—" }));
  return el("div", { className: "panel" },
    el("div", { className: "stats" }, stat("الرهان", fmt(g.bet)), stat("المضاعف", "x" + g.mult), stat("الربح الحالي", fmt(g.payout), "gold")),
    el("div", { className: "card-big", textContent: CARD[g.card] }),
    el("div", { className: "hist" }, g.hist.slice(-8).map((c) => el("i", { textContent: CARD[c] }))),
    el("div", { className: "row3" }, b("▲ أعلى", "high"), b("＝ مساوي", "same"), b("▼ أقل", "low")),
    btn(`جمع ${fmt(g.payout)}`, () => play({ game: "hilo", action: "cash" }), "success"));
}
function diceView() {
  const bet = betBox(), d = last.dice?.dice;
  const face = (a) => el("div", { className: "dice-pair" }, a.map((n) => el("i", { textContent: "⚀⚁⚂⚃⚄⚅"[n - 1] })), el("b", { textContent: a[0] + a[1] }));
  return el("div", { className: "panel" },
    el("p", { className: "hint", textContent: "نرد ضد البنك: المجموع الأعلى يربح x1.9، والتعادل يرجّع رهانك." }),
    bet.node, btn("ارمِ النرد 🎲", () => play({ game: "dice", bet: bet.input.value }), "primary"),
    d ? el("div", { className: "vs" }, el("div", {}, el("small", { textContent: "أنت" }), face(d.you)), el("div", {}, el("small", { textContent: "البنك" }), face(d.bank))) : null);
}
const GAMES = { mines: ["💎", "الماس", minesView], hilo: ["🃏", "هاي لو", hiloView], dice: ["🎲", "نرد", diceView] };

// ---------- الصفحات ----------
function home() {
  const total = me.wins + me.losses, rate = total ? Math.round((me.wins / total) * 100) : 0;
  return el("div", {},
    el("section", { className: "hero" }, el("div", { className: "hero-top" }, avatar(56), el("div", {}, el("h1", { textContent: user.name }), el("small", { textContent: `المستوى ${me.level} · ${me.xp}/1300 XP` }))),
      el("div", { className: "bal", textContent: fmt(me.balance) }), el("small", { textContent: "الرصيد" }),
      el("div", { className: "bar" }, el("i", { style: `width:${Math.min(100, (me.xp / 1300) * 100)}%` }))),
    el("div", { className: "stats" }, stat("الأرباح", fmt(me.profit), "good"), stat("الخسائر", fmt(me.loss), "bad"), stat("الفوز", me.wins), stat("نسبة الفوز", rate + "%")),
    el("h3", { textContent: "العب الآن" }),
    el("div", { className: "tiles" }, Object.entries(GAMES).map(([k, [i, n]]) => el("button", { className: "tile", onclick: () => { game = k; go("games"); } }, el("span", { textContent: i }), el("b", { textContent: n })))));
}
function games() {
  return el("div", {}, el("div", { className: "seg" }, Object.entries(GAMES).map(([k, [i, n]]) => el("button", { className: k === game ? "on" : "", textContent: `${i} ${n}`, onclick: () => { game = k; draw(); } }))), GAMES[game][2]());
}
function commands() {
  const q = el("input", { type: "text", placeholder: "🔍 ابحث عن أمر...", className: "search" }), list = el("div");
  const show = () => {
    const t = q.value.trim();
    list.replaceChildren(...COMMANDS.map((s) => {
      const rows = s.cmds.filter(([n, u, d]) => !t || (n + u + d).includes(t));
      return rows.length ? el("section", { className: "sec" }, el("h3", { style: `border-color:${s.color}`, textContent: s.title }),
        rows.map(([n, u, d]) => el("div", { className: "cmd" }, el("code", { textContent: u ? `${n} ${u}` : n }), el("span", { textContent: d })))) : null;
    }).filter(Boolean));
  };
  q.oninput = show; show();
  return el("div", {}, q, list);
}
const avatar = (s) => (user.avatar ? el("img", { className: "av", width: s, height: s, src: `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=128` }) : el("div", { className: "av ph", textContent: "P" }));
const TABS = [["home", "🏠", "الرئيسية", home], ["games", "🎮", "الألعاب", games], ["cmds", "📜", "الأوامر", commands]];

function go(t) { tab = t; draw(); }
function draw() {
  const t = tab === "admin" ? ["admin"] : TABS.find((x) => x[0] === tab);
  const main = el("main");
  if (tab === "admin") { main.append(el("div", { id: "adm" })); }
  else main.append(t[3]());
  const tabs = user.owner ? [...TABS, ["admin", "⚙️", "الإدارة"]] : TABS;
  root.replaceChildren(
    el("header", {}, el("div", { className: "brand" }, el("div", { className: "logo", textContent: "P" }), el("span", { textContent: "Prime Bank" })), el("div", { className: "chip-bal" }, "💰 " + fmt(me.balance))),
    main,
    el("nav", {}, tabs.map(([k, i, n]) => el("button", { className: k === tab ? "on" : "", onclick: () => go(k) }, el("span", { textContent: i }), el("small", { textContent: n })))));
  if (tab === "admin") admin(document.getElementById("adm"), api);
}

(async () => {
  try {
    await login(); me = await api("me");
    G.mines = me.games.mines || null; G.hilo = me.games.hilo || null;
    if (G.mines) game = "mines"; else if (G.hilo) game = "hilo";
    draw();
    setInterval(() => api("me").then((d) => { me = d; if (!document.querySelector("input:focus")) draw(); }).catch(() => {}), 60000);
  } catch (e) { root.replaceChildren(el("div", { className: "boot" }, el("div", { className: "logo", textContent: "P" }), el("p", { textContent: e.message }))); }
})();
