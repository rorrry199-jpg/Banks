const el = (tag, props = {}, ...kids) => {
  const n = Object.assign(document.createElement(tag), props);
  for (const k of kids.flat()) n.append(k);
  return n;
};
export function admin(app, api) {
let note = null;
const flash = (text, ok = true) => { note = { text, ok }; render(); };

async function render() {
  const s = await api("state");
  app.replaceChildren(el("h1", { textContent: "🏦 لوحة تحكم Prime Bank" }));
  if (note) { app.append(el("div", { className: "msg " + (note.ok ? "ok" : "err"), textContent: note.text })); note = null; }

  const save = (patch) => api("settings", patch).then(() => flash("✅ تم الحفظ")).catch((e) => flash("❌ " + e.message, false));

  // عام
  const prefix = el("input", { type: "text", value: s.settings.prefix, maxLength: 3 });
  const color = el("input", { type: "color", value: s.settings.color });
  const maint = el("input", { type: "checkbox", checked: s.settings.maintenance });
  app.append(el("div", { className: "card" }, el("h2", { textContent: "الإعدادات العامة" }),
    el("label", {}, "البريفكس:", prefix),
    el("label", {}, "لون النظام:", color),
    el("label", {}, maint, "وضع الصيانة (الأونرز فقط يستخدمون البوت)"),
    el("button", { textContent: "حفظ", onclick: () => save({ prefix: prefix.value, color: color.value, maintenance: maint.checked }) })));

  // الأوامر
  const boxes = s.commands.map((n) => { const c = el("input", { type: "checkbox", checked: s.settings.disabled.includes(n), value: n }); return [c, el("label", {}, c, n)]; });
  app.append(el("div", { className: "card" }, el("h2", { textContent: "إيقاف أوامر (المحدّد = موقوف)" }),
    el("div", { className: "cmds" }, boxes.map((b) => b[1])),
    el("button", { textContent: "حفظ الأوامر", onclick: () => save({ disabled: boxes.filter((b) => b[0].checked).map((b) => b[0].value) }) })));

  // الأونرز (للأساسي فقط)
  if (s.isSuper) {
    const id = el("input", { type: "text", placeholder: "آيدي العضو", maxLength: 20 });
    const owners = (a, v) => api("owners", { action: a, id: v }).then(() => flash("✅ تم")).catch((e) => flash("❌ " + e.message, false));
    app.append(el("div", { className: "card" }, el("h2", { textContent: "الأونرز" }),
      el("div", { className: "log", textContent: "أساسيون (config.json): " + s.superOwners.join(", ") }),
      s.owners.map((o) => el("div", { className: "row" }, el("span", { textContent: o }), el("button", { className: "danger", textContent: "حذف", onclick: () => confirm("حذف الأونر " + o + "؟") && owners("remove", o) }))),
      el("div", { className: "row" }, id, el("button", { textContent: "إضافة", onclick: () => confirm("إضافة " + id.value + " كأونر؟ يقدر يعدّل الأوامر والإعدادات.") && owners("add", id.value.trim()) }))));
  }

  // السجل
  app.append(el("div", { className: "card" }, el("h2", { textContent: "آخر العمليات" }),
    el("div", { className: "log" }, s.audit.map((a) => el("div", { textContent: `${new Date(a.t).toLocaleString("ar")} — ${a.by} — ${a.action}` })))));
}

  return render();
}
