# Prime Bank - موقع الـ Activity (الواجهة فقط)

## الهيكل
- `client/`  الواجهة (Vite + Discord Embedded App SDK): رئيسية، ألعاب (الماس / هاي لو / نرد)، أوامر، إدارة.
- `worker/`  Cloudflare Worker: يخدم الواجهة ويحوّل `/api/*` لسيرفر البوت.

## التشغيل
1. `cd client && cp .env.example .env` وضع `VITE_DISCORD_CLIENT_ID` (Application ID).
2. `npm run install:all` ثم `npm run build`.
3. عدّل `API_ORIGIN` في `worker/wrangler.toml` لعنوان سيرفر البوت العام.
4. `npm run deploy` (أو `cd worker && npx wrangler deploy`).
5. Developer Portal → Activities → URL Mappings: Root `/` = دومين الـ Worker.

## ملاحظة
الواجهة تحتاج الـ API الموجود داخل البوت (`panel/server.js` و `panel/webGames.js` في مشروع البوت) ومتغيرات `DISCORD_CLIENT_ID` و `DISCORD_CLIENT_SECRET` و `PANEL_SESSION_SECRET` عليه.
