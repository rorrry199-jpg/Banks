// Cloudflare Worker: يخدم الواجهة (dist) ويحوّل /api/* إلى سيرفر البوت (API_ORIGIN)
export default {
  async fetch(req, env) {
    const u = new URL(req.url);
    if (u.pathname.startsWith("/api/")) return fetch(new Request(new URL(u.pathname + u.search, env.API_ORIGIN), req));
    return env.ASSETS.fetch(req);
  },
};
